/**
 * Goal is to collect Date from TextFile in order of YearmonthDate 
 * Send valid Date of Birth to FileMenuHandler class to print them in sorted and unsorted way 
 * @author Mohammed J Islam
 * Create node and LinkedList date class to store date
 * Create abstract class of DateList
 * Also check for Valid date of birth like month can't be "month<0||month>31" 
 * Date also has to be in the range of date. Length of the Date of Birth has to be eight. 
 */
public class Project3 {
   //static DateGUI ssnGUI;
   public static void main(String[] args) {
      DateGUI ssnGUI = new DateGUI("My SSN GUI", 500,300); 
   }
}